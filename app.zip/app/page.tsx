import Link from "next/link";
 
export default function LandingPage() {
  return (
    <div className="min-h-screen bg-slate-900 text-white font-sans selection:bg-cyan-500 selection:text-white flex flex-col">
     
      {/* --- 1. GLASS HEADER (Built-in for Landing Page only) --- */}
      <header className="sticky top-0 z-50 backdrop-blur-md bg-slate-900/80 border-b border-slate-700">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-8 h-8 text-cyan-400">
              <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 3v1.5M4.5 8.25H3m18 0h-1.5M4.5 12h1.5m-1.5 3.75H3m18 0h-1.5M8.25 19.5V21M12 3v1.5m0 15V21m3.75-18v1.5m0 15V21m-9-1.5h10.5a2.25 2.25 0 002.25-2.25V6.75a2.25 2.25 0 00-2.25-2.25H6.75A2.25 2.25 0 004.5 6.75v10.5a2.25 2.25 0 002.25 2.25z" />
            </svg>
            <span className="text-xl font-bold tracking-wider">PC<span className="text-cyan-400">STORE</span></span>
          </div>
 
          {/* Quick Nav */}
          <Link href="/login" className="px-5 py-2 text-sm font-semibold bg-cyan-600 hover:bg-cyan-500 rounded-full transition shadow-lg shadow-cyan-500/20">
            Sign In
          </Link>
        </div>
      </header>
 
      {/* --- 2. HERO SECTION --- */}
      <section className="flex-1 flex flex-col justify-center items-center text-center px-4 py-20 bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900">
        <div className="max-w-3xl space-y-6 animate-fade-in-up">
          <div className="inline-block px-3 py-1 rounded-full bg-slate-700/50 border border-slate-600 text-xs text-cyan-300 tracking-widest uppercase mb-2">
            Next Gen Hardware
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-100 to-slate-400">
            Power Your Dreams.
          </h1>
          <p className="text-slate-400 text-lg md:text-xl max-w-2xl mx-auto">
            The ultimate destination for high-performance components.
            Built for gamers, creators, and professionals.
          </p>
         
          <div className="pt-4">
            {/* The Big Button for Customers */}
            <Link href="/store" className="inline-flex items-center justify-center px-8 py-4 text-base font-bold text-slate-900 bg-cyan-400 rounded hover:bg-cyan-300 transition transform hover:scale-105 shadow-[0_0_20px_rgba(34,211,238,0.4)]">
              Shop Now
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-5 h-5 ml-2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
              </svg>
            </Link>
          </div>
        </div>
      </section>
 
      {/* --- 3. ROLE SELECTOR GRID (3 CARDS ONLY) --- */}
      <section className="bg-slate-900 py-16 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-bold text-white">Employee & Partner Access</h2>
            <p className="text-slate-500 text-sm mt-2">Restricted access for authorized personnel only</p>
          </div>
 
          {/* GRID ADJUSTED FOR 3 ITEMS */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
           
            {/* CARD 1: ADMIN */}
            <Link href="/login" className="group p-6 rounded-2xl bg-slate-800 border border-slate-700 hover:border-cyan-500/50 hover:bg-slate-800/80 transition-all duration-300 hover:-translate-y-1">
              <div className="w-12 h-12 bg-slate-700 rounded-lg flex items-center justify-center mb-4 group-hover:bg-cyan-900/30 transition-colors">
                 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-cyan-400">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12c0 1.268-.63 2.39-1.593 3.068a3.745 3.745 0 01-1.043 3.296 3.745 3.745 0 01-3.296 1.043A3.745 3.745 0 0112 21c-1.268 0-2.39-.63-3.068-1.593a3.746 3.746 0 01-3.296-1.043 3.745 3.745 0 01-1.043-3.296A3.745 3.745 0 013 12c0-1.268.63-2.39 1.593-3.068a3.745 3.745 0 011.043-3.296 3.746 3.746 0 013.296-1.043A3.746 3.746 0 0112 3c1.268 0 2.39.63 3.068 1.593a3.746 3.746 0 013.296 1.043 3.746 3.746 0 011.043 3.296A3.745 3.745 0 0121 12z" />
                </svg>
              </div>
              <h3 className="text-lg font-bold text-white mb-1 group-hover:text-cyan-400">Admin Panel</h3>
              <p className="text-slate-400 text-sm">System control, user management & logs.</p>
            </Link>
 
            {/* CARD 2: SELLER */}
            <Link href="/seller" className="group p-6 rounded-2xl bg-slate-800 border border-slate-700 hover:border-green-500/50 hover:bg-slate-800/80 transition-all duration-300 hover:-translate-y-1">
              <div className="w-12 h-12 bg-slate-700 rounded-lg flex items-center justify-center mb-4 group-hover:bg-green-900/30 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-green-400">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 21v-7.5a.75.75 0 01.75-.75h3a.75.75 0 01.75.75V21m-4.5 0H2.36m11.14 0H18m0 0h3.64m-1.39 0V9.349m-16.5 11.65V9.35m0 0a3.001 3.001 0 003.75-.615A2.993 2.993 0 009.75 9.75c.896 0 1.7-.393 2.25-1.016a2.993 2.993 0 002.25 1.016c.896 0 1.7-.393 2.25-1.015a3.001 3.001 0 003.75.614m-16.5 0a3.004 3.004 0 01-.621-4.72l1.189-1.19A1.5 1.5 0 015.378 3h13.243a1.5 1.5 0 011.06.44l1.19 1.189a3 3 0 01-.621 4.72m-13.5 8.65h3.75a.75.75 0 00.75-.75V13.5a.75.75 0 00-.75-.75H6.75a.75.75 0 00-.75.75v3.75c0 .415.336.75.75.75z" />
                </svg>
              </div>
              <h3 className="text-lg font-bold text-white mb-1 group-hover:text-green-400">Seller Dashboard</h3>
              <p className="text-slate-400 text-sm">Manage inventory, stock & pricing.</p>
            </Link>
 
            {/* CARD 3: DELIVERY */}
            <Link href="/login" className="group p-6 rounded-2xl bg-slate-800 border border-slate-700 hover:border-orange-500/50 hover:bg-slate-800/80 transition-all duration-300 hover:-translate-y-1">
              <div className="w-12 h-12 bg-slate-700 rounded-lg flex items-center justify-center mb-4 group-hover:bg-orange-900/30 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-orange-400">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 18.75a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 01-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m3 0h1.125c.621 0 1.129-.504 1.09-1.124a17.902 17.902 0 00-3.213-9.193 2.056 2.056 0 00-1.58-.86H14.25M16.5 18.75h-2.25m0-11.177v-.958c0-.568-.422-1.048-.987-1.106a48.554 48.554 0 00-10.026 0 1.106 1.106 0 00-.987 1.106v7.635m12-6.677v6.677m0 4.5v-4.5m0 0h-12" />
                </svg>
              </div>
              <h3 className="text-lg font-bold text-white mb-1 group-hover:text-orange-400">Delivery Hub</h3>
              <p className="text-slate-400 text-sm">Track shipments & logistics.</p>
            </Link>
 
          </div>
        </div>
      </section>
 
      {/* --- 4. FOOTER --- */}
      <footer className="border-t border-slate-800 py-8 text-center bg-slate-900">
        <p className="text-slate-600 text-sm">© 2026 PC Store Project. University Group Assignment.</p>
      </footer>
    </div>
  );
}