"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import axios from "axios";
import Link from "next/link";
import { z } from "zod";
import Navbar from "../components/Navbar";

// --- ZOD SCHEMA ---
// We use .refine() to check if passwords match
const registerSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  email: z.string().email({ message: "Invalid email address" }),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"], // This tells Zod to attach the error to the confirmPassword field
});

export default function RegisterPage() {
  const router = useRouter();
  const [formData, setFormData] = useState({ 
    name: "", 
    email: "", 
    password: "", 
    confirmPassword: "" 
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [apiError, setApiError] = useState("");
  const [success, setSuccess] = useState("");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    if (errors[e.target.name]) {
      setErrors({ ...errors, [e.target.name]: "" });
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setApiError("");
    setSuccess("");
    setErrors({});

    // --- VALIDATION: Zod Parse ---
    const result = registerSchema.safeParse(formData);

    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.issues.forEach((issue) => {
        fieldErrors[issue.path[0]] = issue.message;
      });
      setErrors(fieldErrors);
      return;
    }

    try {
      // --- AXIOS FETCHING (2/5) ---
      const res = await axios.post("http://localhost:3000/auth/register", {
        name: formData.name,
        email: formData.email,
        password: formData.password, // We don't send confirmPassword to backend
      });

      setSuccess("Registration successful! Redirecting...");
      setTimeout(() => router.push("/login"), 2000);
      
    } catch (err: any) {
      console.error(err);
      setApiError(err.response?.data?.message || "Registration failed.");
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white font-sans flex flex-col">
      <Navbar />
      <div className="flex-1 flex items-center justify-center py-10">
        <div className="w-full max-w-md p-8 bg-slate-800 border border-slate-700 rounded-2xl shadow-xl">
          <h2 className="text-3xl font-bold text-center mb-6 text-cyan-400">Create Account</h2>
          
          {apiError && <div className="bg-red-500/10 border border-red-500 text-red-400 p-3 rounded mb-4 text-sm text-center">{apiError}</div>}
          {success && <div className="bg-green-500/10 border border-green-500 text-green-400 p-3 rounded mb-4 text-sm text-center">{success}</div>}

          <form onSubmit={handleRegister} className="space-y-4">
            {/* Name Field */}
            <div>
              <label className="block text-sm text-slate-400 mb-1">Full Name</label>
              <input 
                name="name" 
                onChange={handleChange} 
                className={`w-full p-3 bg-slate-900 border rounded focus:outline-none transition text-white ${
                  errors.name ? "border-red-500" : "border-slate-600 focus:border-cyan-400"
                }`} 
              />
              {errors.name && <p className="text-red-400 text-xs mt-1">{errors.name}</p>}
            </div>

            {/* Email Field */}
            <div>
              <label className="block text-sm text-slate-400 mb-1">Email</label>
              <input 
                name="email" 
                type="email" 
                onChange={handleChange} 
                className={`w-full p-3 bg-slate-900 border rounded focus:outline-none transition text-white ${
                  errors.email ? "border-red-500" : "border-slate-600 focus:border-cyan-400"
                }`} 
              />
              {errors.email && <p className="text-red-400 text-xs mt-1">{errors.email}</p>}
            </div>

            {/* Password Field */}
            <div>
              <label className="block text-sm text-slate-400 mb-1">Password</label>
              <input 
                name="password" 
                type="password" 
                onChange={handleChange} 
                className={`w-full p-3 bg-slate-900 border rounded focus:outline-none transition text-white ${
                  errors.password ? "border-red-500" : "border-slate-600 focus:border-cyan-400"
                }`} 
              />
              {errors.password && <p className="text-red-400 text-xs mt-1">{errors.password}</p>}
            </div>

            {/* Confirm Password Field */}
            <div>
              <label className="block text-sm text-slate-400 mb-1">Confirm Password</label>
              <input 
                name="confirmPassword" 
                type="password" 
                onChange={handleChange} 
                className={`w-full p-3 bg-slate-900 border rounded focus:outline-none transition text-white ${
                  errors.confirmPassword ? "border-red-500" : "border-slate-600 focus:border-cyan-400"
                }`} 
              />
              {errors.confirmPassword && <p className="text-red-400 text-xs mt-1">{errors.confirmPassword}</p>}
            </div>

            <button type="submit" className="w-full py-3 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded transition shadow-lg shadow-cyan-500/20">
              Register
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}