"use client";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import axios from "axios";
import Navbar from "../../components/Navbar";

export default function DeliveryManDetails() {
  const params = useParams(); 
  const id = params.id; // Access the dynamic ID
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    const token = localStorage.getItem("access_token");
    
    if (id && token) {
       // --- REQUIREMENT: Axios Fetching (5 of 5)  ---
       // Fetch specific data based on the dynamic ID
       axios.get(`http://localhost:3000/deliveryman/${id}`, {
          headers: { Authorization: `Bearer ${token}` }
       })
       .then(res => setData(res.data))
       .catch(err => console.error(err));
    }
  }, [id]);

  if (!data) return <div className="min-h-screen bg-slate-900 text-white p-10">Loading ID: {id}...</div>;

  return (
    <div className="min-h-screen bg-slate-900 text-white font-sans">
      <Navbar />
      <div className="max-w-3xl mx-auto p-10">
        <div className="bg-slate-800 p-8 rounded-2xl border border-slate-700 shadow-xl">
          <h2 className="text-2xl font-bold mb-6 text-cyan-400 border-b border-slate-700 pb-4">
             Delivery Man Profile
          </h2>
          <div className="space-y-4 text-lg">
              <div className="flex justify-between">
                  <span className="text-slate-400">Employee ID:</span>
                  <span className="font-mono text-white">{data.id}</span>
              </div>
              <div className="flex justify-between">
                  <span className="text-slate-400">Name:</span>
                  <span className="text-white">{data.name}</span>
              </div>
              <div className="flex justify-between">
                  <span className="text-slate-400">Status:</span>
                  <span className="px-3 py-1 bg-green-500/20 text-green-400 rounded-full text-sm font-bold">
                    {data.status}
                  </span>
              </div>
          </div>
        </div>
      </div>
    </div>
  );
}