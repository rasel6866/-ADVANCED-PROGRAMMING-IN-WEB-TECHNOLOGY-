"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import axios from "axios";
import Link from "next/link";
import { z } from "zod";
import Navbar from "../components/Navbar";

// --- ZOD SCHEMA ---
const loginSchema = z.object({
 // email: z.string().email({ message: "Invalid email address format" }),
  password: z.string().min(1, { message: "Password is required" }),
});

export default function LoginPage() {
  const router = useRouter();
  const [formData, setFormData] = useState({ email: "", password: "" });
  
  // State for Zod validation errors (field-specific)
  const [errors, setErrors] = useState<Record<string, string>>({});
  // State for API/Axios errors
  const [apiError, setApiError] = useState("");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    // Clear error for this field when user types
    if (errors[e.target.name]) {
      setErrors({ ...errors, [e.target.name]: "" });
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setApiError("");
    setErrors({});

    // --- VALIDATION: Zod Parse ---
    const result = loginSchema.safeParse(formData);

    if (!result.success) {
      // Map Zod errors to our state object
      const fieldErrors: Record<string, string> = {};
      result.error.issues.forEach((issue) => {
        // Path[0] corresponds to the field name
        fieldErrors[issue.path[0]] = issue.message;
      });
      setErrors(fieldErrors);
      return; // Stop execution if validation fails
    }

    try {
      // --- AXIOS FETCHING (1/5) ---
      const res = await axios.post("http://localhost:3000/auth/login", formData, {
        headers: { "Content-Type": "application/json" },
      });

      localStorage.setItem("access_token", res.data.token);
      router.push("/dashboard");

    } catch (err: any) {
      console.error(err);
      setApiError(err.response?.data?.message || "Login failed. Check server connection.");
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white font-sans flex flex-col">
      <Navbar />
      <div className="flex-1 flex items-center justify-center">
        <div className="w-full max-w-md p-8 bg-slate-800 border border-slate-700 rounded-2xl shadow-xl">
          <h2 className="text-3xl font-bold text-center mb-6 text-cyan-400">Sign In</h2>
          
          {/* Global API Error */}
          {apiError && (
            <div className="bg-red-500/10 border border-red-500 text-red-400 p-3 rounded mb-4 text-sm text-center">
              {apiError}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm text-slate-400 mb-1">Email</label>
              <input
                name="email"
                type="email" // Type email handles basic HTML validation, Zod handles specific format
                onChange={handleChange}
                className={`w-full p-3 bg-slate-900 border rounded focus:outline-none transition text-white ${
                  errors.email ? "border-red-500" : "border-slate-600 focus:border-cyan-400"
                }`}
                placeholder="admin@pcstore.com"
              />
              {errors.email && <p className="text-red-400 text-xs mt-1">{errors.email}</p>}
            </div>

            <div>
              <label className="block text-sm text-slate-400 mb-1">Password</label>
              <input
                name="password"
                type="password"
                onChange={handleChange}
                className={`w-full p-3 bg-slate-900 border rounded focus:outline-none transition text-white ${
                  errors.password ? "border-red-500" : "border-slate-600 focus:border-cyan-400"
                }`}
                placeholder="••••••••"
              />
               {errors.password && <p className="text-red-400 text-xs mt-1">{errors.password}</p>}
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded transition shadow-lg shadow-cyan-500/20"
            >
              Login
            </button>
          </form>
          
          <p className="mt-6 text-center text-slate-500 text-sm">
            Don't have an account?{" "}
            <Link href="/register" className="text-cyan-400 hover:underline">
              Register
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}