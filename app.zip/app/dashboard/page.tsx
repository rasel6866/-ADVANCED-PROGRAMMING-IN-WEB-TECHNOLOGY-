"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import axios from "axios";
import Navbar from "../components/Navbar";
import Link from "next/link";

export default function Dashboard() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [stats, setStats] = useState<any>({ sales: 0, orders: 0 }); // Default values
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // 1. Check Authentication on Mount
    const token = localStorage.getItem("access_token");
    if (!token) {
      router.push("/login");
      return;
    }

    const fetchData = async () => {
      try {
        // --- REQUIREMENT: Axios Fetching (3 of 5)  ---
        // Fetch User Profile
        const profileRes = await axios.get("http://localhost:3000/users/profile", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setUser(profileRes.data);

        // --- REQUIREMENT: Axios Fetching (4 of 5)  ---
        // Fetch Dashboard Stats (Sales/Orders)
        // Ensure you have a backend endpoint like /dashboard/stats or similar
        const statsRes = await axios.get("http://localhost:3000/dashboard/stats", {
           headers: { Authorization: `Bearer ${token}` },
        });
        setStats(statsRes.data);

      } catch (error) {
        console.error("Dashboard data fetch failed", error);
        // Optional: Logout if token is invalid
        // localStorage.removeItem("access_token");
        // router.push("/login");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [router]);

  // Loading State
  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-cyan-400 text-xl font-bold animate-pulse">Loading Dashboard...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 text-white font-sans">
      <Navbar />
      <div className="max-w-7xl mx-auto p-6">
        <header className="mb-10 border-b border-slate-800 pb-6">
          <h1 className="text-4xl font-bold">
            Welcome, <span className="text-cyan-400">{user?.name || "User"}</span>
          </h1>
          <p className="text-slate-400 mt-2">Here is your system overview.</p>
        </header>

        {/* Dashboard Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          <div className="p-6 bg-slate-800 rounded-xl border border-slate-700 shadow-lg">
            <h3 className="text-slate-400 text-sm uppercase tracking-wider">Total Revenue</h3>
            <p className="text-3xl font-bold mt-2 text-white">${stats.sales || "0.00"}</p>
          </div>
          <div className="p-6 bg-slate-800 rounded-xl border border-slate-700 shadow-lg">
             <h3 className="text-slate-400 text-sm uppercase tracking-wider">Pending Orders</h3>
            <p className="text-3xl font-bold mt-2 text-white">{stats.orders || "0"}</p>
          </div>
          
          {/* REQUIREMENT: Link to Dynamic Route [cite: 4] */}
          <Link href="/deliveryman/101" className="group p-6 bg-slate-800 rounded-xl border border-slate-700 hover:border-cyan-500 transition cursor-pointer">
            <h3 className="text-cyan-400 font-bold group-hover:text-cyan-300">Manage Delivery Man #101 &rarr;</h3>
            <p className="text-slate-400 text-sm mt-1">Click to test dynamic routing</p>
          </Link>
        </div>
      </div>
    </div>
  );
}